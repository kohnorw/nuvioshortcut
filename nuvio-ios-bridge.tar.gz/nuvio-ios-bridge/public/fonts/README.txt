JetBrains Sans goes here.

The app renders in JetBrains Sans (core/ui/Theme.kt in NuvioMobile). The font
files are not bundled with this project: the copy in the Nuvio repo carries an
"All rights reserved" notice with no license grant embedded, so redistributing
it isn't mine to do.

Run scripts/fetch-fonts.sh once to pull the three weights from the public
NuvioMobile repo into this directory, then rebuild. Without them the app falls
back to the system font and works normally, just not as a typographic match.
