#!/usr/bin/env sh
# Pulls JetBrains Sans out of the NuvioMobile repo so the web app renders in
# the same typeface as the native one. Run this once before building.
#
# The fonts are not bundled here: they're JetBrains' to license, not mine to
# redistribute. This fetches them from the same public repo you already use.
# Skip it and the app falls back to the system font — everything still works,
# it just won't be a typographic match.
set -eu

BASE="https://raw.githubusercontent.com/NuvioMedia/NuvioMobile/cmp-rewrite/composeApp/src/commonMain/composeResources/font"
DEST="$(dirname "$0")/../public/fonts"
mkdir -p "$DEST"

for weight in regular semibold bold; do
  echo "Fetching jetbrains_sans_${weight}.ttf"
  curl -fsSL "$BASE/jetbrains_sans_${weight}.ttf" -o "$DEST/jetbrains_sans_${weight}.ttf"
done

echo "Done. Rebuild with: docker compose up -d --build"
