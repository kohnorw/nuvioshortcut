// VLC for iOS registers two useful URL schemes.
//
// vlc-x-callback:// is the good one: it takes a properly encoded url parameter
// and can bounce back to the app that called it when playback ends. vlc:// is
// the crude fallback — you strip the scheme off the media URL and glue what's
// left onto vlc://, which breaks on URLs containing a query string, so it is
// only there for the rare build where x-callback misbehaves.

export function xCallback(mediaUrl, { filename, successUrl } = {}) {
  const params = new URLSearchParams({ url: mediaUrl });
  if (filename) params.set('filename', filename);
  if (successUrl) params.set('x-success', successUrl);
  return `vlc-x-callback://x-callback-url/stream?${params.toString()}`;
}

export function legacy(mediaUrl) {
  return `vlc://${mediaUrl.replace(/^https?:\/\//i, '')}`;
}

export function build(mediaUrl, options = {}) {
  return {
    open: xCallback(mediaUrl, options),
    fallback: legacy(mediaUrl),
    direct: mediaUrl,
  };
}
